Place your own version of templates into this file to override the default ones.
For instance, if there's a template at: `src/web/templates/evennia_general/index.html`
and you want to replace it, create the file `game/gamesrc/web/template_overrides/evennia_general/index.html`
and it will be loaded instead.